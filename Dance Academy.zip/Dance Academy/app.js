const express = require("express");
const fs = require("fs");
const app = express();

app.use(express.urlencoded())
app.set("view engine", "pug");
app.set("views", "E:/Web Development Projects/Dance Academy/Views");

app.get("/", (req, res)=>{
    res.render("index");
});

app.post("/", (req, res)=>{
    fs.appendFileSync("Output.txt", `Name: ${req.body.name}, Email: ${req.body.email}, Location: ${req.body.loc}\n`)
    res.render("index");
});

app.listen(80, ()=>{
    console.log(`Server Started at http://127.0.0.1:${80}`)
});